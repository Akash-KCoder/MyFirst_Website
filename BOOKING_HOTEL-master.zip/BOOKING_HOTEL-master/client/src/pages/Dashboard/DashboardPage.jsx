import React from 'react';
import DashBoard from '../../components/Dashboard';

const DashboardPage = () => {
    return (
        <div>
            <DashBoard />
        </div> 
    );
};

export default DashboardPage;