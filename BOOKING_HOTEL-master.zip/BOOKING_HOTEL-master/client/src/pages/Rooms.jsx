import React from 'react';
import AllRooms from '../components/Roomes/AllRooms';

const Rooms = () => {
    return (
      <div style={{ background: "#f3f3f3" }}>
        <AllRooms />
      </div>
    );
};

export default Rooms;