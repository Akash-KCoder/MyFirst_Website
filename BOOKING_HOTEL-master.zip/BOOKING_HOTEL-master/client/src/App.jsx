import React from 'react';
import Routers from './routers/Routers';

const App = () => {
  return (
    <>
      <Routers />
    </>
  );
};

export default App;